import { NextResponse,NextRequest } from "next/server";
import jwt, { TokenExpiredError } from "jsonwebtoken";
import argon2 from "argon2";
import { buildValidationError } from "@/utils/api/validation";
import { resetPasswordSchema } from "@/validators/forgot.schema";
import updateUserPassword from "@/db/repository/updateUserPassword";
export async function POST(request: NextRequest) {
    try{
        const { email, password, token } = await request.json();
        const parseResult = resetPasswordSchema.safeParse({ email, password, token });
        if (!parseResult.success) {
            return NextResponse.json(buildValidationError(parseResult.error), { status: 400 });
        }

        const jwtSecret = process.env.JWT_SECRET;
        if (!jwtSecret) {
            console.error("[reset] JWT_SECRET missing");
            return NextResponse.json({ message: "Server configuration error", success: false }, { status: 500 });
        }

        //verify token
        try{
            const decoded = jwt.verify(token, jwtSecret) as { email: string; purpose?: string };
            if(decoded.email !== email || decoded.purpose !== "password_reset"){
                return NextResponse.json({ message: "Session expired, please request a new one", success: false },{ status: 400 });
            }
                //update password in db
                const pepper = process.env.PASSWORD_PEPPER || "";
                const hashedPassword = await argon2.hash(password + pepper);
                //update password in db
                // Assuming you have a function updateUserPassword that takes email and new hashed password
                const updateResult = await updateUserPassword(email, hashedPassword);
                return NextResponse.json(updateResult, { status: updateResult.success ? 200 : 400 });

        }
        catch(error){
            if (error instanceof TokenExpiredError) {
                return NextResponse.json({ message: "Your reset session has expired. Please request a new reset code.", success: false },{ status: 400 });
            }
            return NextResponse.json({ message: "Invalid reset session. Please request a new one.", success: false },{ status: 400 });
        }
        
    }
    catch(error){
        return NextResponse.json({ message: "Error occurred while processing reset password request: "+error, success: false },{ status: 500 });
    }
}